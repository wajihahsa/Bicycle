# 🚴 Bicycle Website

Simple static website about bicycles.

## Features
- Clean UI
- Responsive layout
- Sections: Home, Types, Gallery

## How to Run
Just open `index.html` in your browser.

## Author
Gudhal Production
